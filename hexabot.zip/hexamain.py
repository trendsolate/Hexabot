import discord
from discord import app_commands
from discord.ext import commands, tasks 
from itertools import cycle

import os 
import TOKEN
from TOKEN import TOKEN

intents = discord.Intents.all()
intents.message_content = True

client = commands.Bot(command_prefix="/" , intents=discord.Intents.all())

bot_status = cycle(["Made by Trendsolate", "From the HEX Network", "Listening to your conversations", "Reading a book", "Waiting for requests", "Playing Fortnite"])

@tasks.loop(minutes=30)
async def change_status():
    await client.change_presence(activity=discord.Game(next(bot_status)))

@client.event
async def on_ready():
    # this runs when the account is logged into
    print("Yo Hexa at your service ans logged in as {0.user}".format(client))
    change_status.start()
    try:
        synced = await client.tree.sync()
        print(f"Synced {len(synced)} command(s)")

    except Exception as e:
        print(e) 
        

@client.event 
async def on_message(message):
    if message.author == client.user:
        return
    
    if message.content.startswith('?hello'):
        await message.channel.send('Yo wsg !')


@client.event 
async def on_message(message):
    if message.author == client.user:
        return
    
    if message.content.startswith('?how is it going'):
        await message.channel.send('All good bruv, wbu?')


@client.event 
async def on_message(message):
    if message.author == client.user:
        return
    
    if message.content.startswith('?wsg chat'):
        await message.channel.send('Hey how you doing?')




@client.tree.command(name="hello" , description="Responds hello")
async def hello(interaction: discord.Interaction):
    await interaction.response.send_message("Yo wsg !")




client.run(TOKEN)